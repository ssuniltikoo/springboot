package com.jpm.mvc.services;

public interface LoginService {
	public boolean authenticateUser(String userName, String password);
}
