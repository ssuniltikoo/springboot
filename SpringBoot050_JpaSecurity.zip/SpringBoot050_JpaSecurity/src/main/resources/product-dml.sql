INSERT into PRODUCTS VALUES (1,'PS/2 Mouse','Logitech PS/2 Mouse with Wheel',300);
INSERT into PRODUCTS VALUES (2,'PS/2 Keyboard','Logitech PS/2 Keyboard - Standard 103 Keys',400);
